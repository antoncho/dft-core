# 🧬 Scroll: Creator Crowdfunding Cluster

## Purpose
Enable creators to launch funding rounds with on-chain tools, vesting logic, and non-custodial routing.

## Mechanics
- NFT/SBT-based supporter tiers
- Vesting vaults for fair payout
- Auto-split to contributor DAOs
