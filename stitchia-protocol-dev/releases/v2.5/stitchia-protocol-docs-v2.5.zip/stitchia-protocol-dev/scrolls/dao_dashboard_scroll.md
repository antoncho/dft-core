---
title: "🧬 Scroll: DAO Dashboard"
classification: Governance+Ethics+StrategicDesign
validators:
  - role: "Data Steward"
  - role: "Governance Architect"
license: Public-Licensed / CodexLinked
tags: [dashboard, governance, treasury, proposals]
links:
  - stitchia-protocol-dev/scrolls/genesys_nft_mint.md
dashboard: {"governance":{"roles":["Anchor","Architect","Steward","Initiator"],"counts":{"Anchor":24,"Architect":18,"Steward":30,"Initiator":17}},"treasury":{"total_eth":3567,"staking_eth":1984,"protocol_eth":1007,"updated_at":"2025-09-05T00:00:00Z"},"proposals":{"items":[{"title":"Staking Program Iteration","status":"In Progress","age_days":5},{"title":"Treasury Allocation Adjustment","status":"Active","age_days":2},{"title":"Incentive Structures Update","status":"Active","age_days":7}]}}
---

# 🧬 DAO Dashboard

This scroll defines the DAO Dashboard framing used for governance visibility.

## Governance (Spiral Roles)
- Roles: Anchor, Architect, Steward, Initiator
- Metric: Spiral Members (example: 89)
- Display: Donut showing distribution by role

## Treasury
- Total ETH: sum of Staking + Protocol
- Buckets: Staking, Protocol (example values for mock)

## Proposals
- Status: Active, In Progress, Completed
- Cards: show title and status with age

## Wallet Integration
- Connect Wallet for role-aware UX and proposal creation

## Ethics
Display avoids implying financial returns. Governance metrics emphasize participation and stewardship.
